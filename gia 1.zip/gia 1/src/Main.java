import java.util.Scanner;

public class Main {

     static Scanner teclado;

    public static void main(String[] args) {
        ///punto 1
        teclado = new Scanner(System.in);

        int[] arreglo = new int[8];
        int validos = 0;

        for (int i = 0; i < 4; i++) {
            arreglo[i] = i + 10;
            validos++;
        }


        float prom = 0;
        prom = promedio(arreglo, validos);

        System.out.println(prom);

        ///punto 2

        int num = 23;


        int par = esPar(num);

        if (par == 1) {
            System.out.println("es par");
        } else {
            System.out.println("no es par");
        }

        ///punto 3 y 4

        int numPrimo = 0;

        for (int i = 1; i < 100; i++) {
            numPrimo = numPrimos(i);
            if (numPrimo == 1) {
                System.out.println(i);
            }
        }

        ///punto 6

        String s;

        do {
            System.out.println("ingresa numero");
            int num2 = teclado.nextInt();

            esPrimo(num2);

            System.out.println("continuar?(s/n)");
            s = teclado.next();

        } while (s == "s");


        //punto 7

        int suma=0;

        for (int i = 0; i < 10; i++) {
            suma = suma + i;
        }
        System.out.println(suma);


        ///punto 8

        int cantNumPos=0;
        int num3=0;

        do{
            System.out.println("ingresa numero");
            num3 = teclado.nextInt();
            cantNumPos = cantPositivos(num3);
            System.out.println("continuar?(s/n)");
            s = teclado.next();

        }while(s=="s");
        System.out.println("la cantida de numeros positivos es :"cantNumPos);

        System.out.println("Hello world!");


        teclado.close();
    }

    public static float promedio(int arrray[], int validos)
    {
        float prom=0;
        int suma=0;

        for(int i=0;i<validos;i++) {

        suma += arrray[i];

        }

        prom = (float)suma/(float)validos;

        return prom;
    }

    public static int esPar(int num)
    {
        if(num%2 == 0)        {
            return 1;
        }else
        {
            return -1;
        }
    }

    public static int numPrimos(int numero){

        int contador=1;
        int aux=0;
        while((numero%contador) ==0 || contador < numero)
        {
            if((numero%contador)==0)
            {
                aux++;
            }
            contador++;

        }

        if(aux == 2)
        {
            return 1;
        }else
        {
            return -1;
        }
    }

    public static void esPrimo(int numero){

        int resultado = 0;
            resultado = numPrimos(numero);

            if (resultado == 1) {
                System.out.println("Es primo.");
            } else {

                System.out.println("No es primo.");
            }
    }

    public static int cantPositivos(int num)
    {
        int cant=0;
        if(num>=0)
        {
            cant++;
        }

        return cant;
    }
}