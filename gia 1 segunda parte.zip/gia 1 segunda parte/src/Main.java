import java.util.*;


public class Main {

    static Scanner teclado;

    public static void main(String[] args) {

        teclado = new Scanner(System.in);


        int num;
        int aux;

        ///punto 9
        System.out.println("punto 9");

        System.out.println("hola decime un año");
        num = teclado.nextInt();

        aux = EsBiciesto(num);

        if(aux == -1)
        {
            System.out.println("no es biciesto");
        }else{
            System.out.println("es biciensto");
        }

        //punto 10
        System.out.println("punto 10");
        char letra;

        letra = teclado.next().charAt(0);

        num = letra;

        System.out.println("la letra " + letra +" en ascii es "+ num );

        ///punto 11
        int num2;

        num = 30;
        num2 = 2;

        aux = num*num2;

        System.out.println("punto 11");
        System.out.println(aux);

        ///punto 12
        System.out.println("punto 12");

        ///punto 20
        System.out.println("punto 20");

        System.out.println("hola decime un numero");

        num = teclado.nextInt();

        System.out.println("otro");

        num2 = teclado.nextInt();

        for(int i=0;i<10;i++)
        {



                aux = (int) (Math.random() * (num - num2 + 1) + num2);
                System.out.println(aux);
        }
        ///punto 


        teclado.close();
    }

    static public int EsBiciesto(int num)
    {

        if((num%4)==0)
        {
            return 1;
        }else
        {
            return -1;
        }
    }

}